import time
import tests
import subprocess

def main():
    subprocess.call(['clear'])
    initialTime = "DIMM stress test started " + \
    time.strftime("%A %b, %I:%M:%S%p", time.localtime())
    print initialTime
    test = tests.Tests()
    test.memTest()

    while True:
        time.sleep(1)
        dFail = test.checkMCE()
        if not dFail == None:
            subprocess.call(['clear'])
            print initialTime + "\n\nCurrent DIMM Failures:\t" + " ".join(dFail)

if __name__ == "__main__":
    main()