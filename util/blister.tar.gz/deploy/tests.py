import subprocess
import os
import sys
if not __debug__:
    import broadwell


class Tests:
    __CONST_PATH_MCE = '/var/log/mcelog'
    __testRunning = False
    __DIMM_LOC = ['A0', 'A1', 'B0', 'B1', 'C0', 'C1', 'D0',
                  'D1', 'E0', 'E1', 'F0', 'F1', 'G0', 'G1', 'H0', 'H1']
    __CONST_PATH = '/opt/mem-chk-tools/IDK/'
    __idk_running = False

    def __init__(self):
        self.__mceLen = 0
        self.__dimm_errors = []
        self.__bw = None


    def memTest(self):  # todo:Automatic resizing of memtester memory allocation instead of by core.  Will take a little longer, but more accurate
        if Tests.__testRunning:
            print "Only one test allowed to run at a time..."
            return
        
        numCores = self.__getCores()
        mem = self.__freeMem()
        memPerCore = (mem - self.__minMem())/numCores  # May need to do max cores minus 1 then see what's left to be taken up in memory
        i = 0
        Tests.__testRunning = True
        while(i < numCores):
            self.__invokeMemtester(memPerCore)
            i += 1

    def __minMem(self):
        block_size = [500,125,25]
        cur_free = self.__freeMem()
        num_cores = self.__getCores()
        min_start = 1500 # May need to change this as more server types become available(ex:Tachyon/Barkley16)
        iniMem = (cur_free - min_start) / (num_cores / 2)
        
        for b in block_size:
            for i in range(0,num_cores/2):
                self.__invokeMemtester(iniMem)
            cur_free = self.__freeMem()
            while True:
                self.__invokeMemtester(b)
                if cur_free > self.__freeMem():
                    cur_free = self.__freeMem()
                else:
                    self.stopMemTest()
                    iniMem = cur_free / (num_cores / 2)
                    break

        return cur_free

    def __invokeMemtester(self,amtMem):# Need to watch this, may have to change from pid to &
        ret  = subprocess.Popen(['memtester', str(amtMem)],stdout=open(os.devnull,'w')).pid        

    def __getCores(self):
        ret = subprocess.Popen(['lscpu'], stdout=subprocess.PIPE).communicate()[0]
        return int(ret[ret.find('CPU('):].split()[1])

    def __freeMem(self):
        ret = subprocess.Popen(['free', '-m'], stdout=subprocess.PIPE).communicate()[0]
        i = 0
        while (ret[i:i+1] != "\n"):
            i += 1
        i += 1
        return int(ret[i:].split()[3])

    def getDimmErrors(self):
        return self.__dimm_errors

    def __iniMemChk(self):  # Sets up IDK interface for finding location of DIMMS
        if Tests.__idk_running == False:  # todo:Use ps ax to see if process is actually running, instead of lazy check            
            tStr = Tests.__CONST_PATH + 'idk_core/'            
            os.chdir(tStr)
            subprocess.Popen(['./idk_core', '/listen', '/no_pat', '&'],stdout=open(os.devnull,'w')).pid
            if self.__bw == None:
                self.__bw = broadwell.connect('127.0.0.1')
            Tests.__idk_running = True

    def getDimm(self, addr):  # Get DIMM location by address
        self.__iniMemChk()        
        ret = self.__bw.AT_forward_translate(int('0x'+addr,16))
        return Tests.__DIMM_LOC[int(str(ret['socket'])+str(ret['imc'])+str(ret['channel'])+str(ret['dimm']), 2)]

    def checkMCE(self):# Need to implement for thermal,overflow,etc.  Right now could give false positive, memory only
        self.__iniMemChk()
        if os.path.getsize(Tests.__CONST_PATH_MCE) > self.__mceLen:  # todo:Find way to read partial file, maybe by byte instead of parsing whole file again for new errors            
            self.__mceLen = os.path.getsize(Tests.__CONST_PATH_MCE)
            cnt = 0
            with open(Tests.__CONST_PATH_MCE, 'r') as f:            
                for l in f:   #f is file, l reads lines from file(weird way to do it, would think l in f.readlines())
                    if l.find('MISC') > -1:                        
                        if l.find('ADDR') > -1:                            
                            tL = l.split()
                            dimm = self.getDimm(tL[len(tL) - 1])
                            if dimm not in self.__dimm_errors:
                                self.__dimm_errors.append(dimm)
                    if l.find("Transaction:") > -1:
                        if l.find("Memory") < 0:
                            raise ValueError('REPORT THIS ERROR IMMEDIATELY TO CHRIS!!!\nThis is an overflow, thermal, or other type error...')
                    cnt += 1
                print "Lines counted in File:\t" + str(cnt)
                return self.__dimm_errors
        return None


    def stopMemTest(self):
        subprocess.call(['pkill','-9','memtester'])
        Tests.__testRunning = False


    def __del__(self):
        subprocess.call(['pkill','-9','memtester'])
        Tests.__testRunning = False
