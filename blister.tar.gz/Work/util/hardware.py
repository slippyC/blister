import subprocess
import os
import install
import menu
import time
import tests

# Memory Related
def freeMem():  # Free Memory on system
    ret = subprocess.Popen(
        ['free', '-m'], stdout=subprocess.PIPE).communicate()[0]
    i = 0
    while (ret[i:i+1] != "\n"):
        i += 1
    i += 1
    return int(ret[i:].split()[3])

def memInfo():
    while True:
        subprocess.call(['clear'])       
        print "Choose action to perform:\n\n" \
            "1. Serial\n2. Mem Test\n3. Previous Menu\n\n"
        uI = raw_input("Enter Choice:")
        subprocess.call(['clear'])    
        if uI == "1":
            ret = subprocess.Popen(['dmidecode','-t','17'],stdout=subprocess.PIPE).communicate()[0].split("\n")
            loc = []
            s = []
            p = []
            for l in ret:
                if l.find('Locator') > -1 and l.find('BANK') == -1:
                    loc.append(l.split(":")[1])
                elif l.find('Serial') > -1:
                    s.append(l.split(':')[1])
                elif l.find('Part') > -1:
                    p.append(l.split(':')[1])
            print "Location\t\tPart Number\t\tSerial"
            print "******************************************************************"
            for i in range(0,len(loc)):
                print loc[i] + "\t\t" + p[i] + "\t" + s[i]
            uI = raw_input("\n\nPress enter to continue...")
        elif uI == "2":
            initialTime = "DIMM stress test started " + \
            time.strftime("%A %b, %I:%M:%S%p", time.localtime())
            print initialTime
            test = tests.Tests()
            if __debug__ == False:
                test.memTest()

            while True:
                time.sleep(1)
                dFail = test.checkMCE()
                if not dFail == None:
                    call(['clear'])
                    print initialTime + "\n\nCurrent DIMM Failures:\t" + " ".join(dFail)
        elif uI == "3":
            break


# CPU Related
def cores():  # Number of cores including hyper-threading
    ret = subprocess.Popen(['lscpu'], stdout=subprocess.PIPE).communicate()[0]
    return int(ret[ret.find('CPU('):].split()[1])

def cpuInfo():
    return subprocess.Popen(['lscpu'],stdout=subprocess.PIPE).communicate()[0]


# HD Related
def hdInfo(hd="-1", filter='Serial'):  # todo:Need to do a lot of work here.  Serial, select certain drive, maybe list the drives and they choose or all option with Serial choice
    subprocess.call(['clear'])
    drives = __lsblk()
    if filter == "Serial":
        for d in drives:
            ret = subprocess.Popen(['smartctl','-i','/dev/' + d[0]],stdout=subprocess.PIPE).communicate()[0]
            print "/dev/" + d[0] + ":\t" + ret[ret.find('Serial'):].split('\n')[0].split(':')[1]
    elif filter == "Read":
        for d in drives:
            subprocess.call(['hdparm','-t','/dev/' + d[0]])
    elif filter == "SATA":
        for d in drives:
            ret = subprocess.Popen(['smartctl','-i','/dev/'+d[0]],stdout=subprocess.PIPE).communicate()[0]
            ret = ret[ret.find('SATA'):]
            print "/dev/" + d[0] + ":\t" + ret.split(':')[1] + ret.split(':')[2].split('\n')[0]

def __lsblk():
    retVal = []
    ret = subprocess.Popen(['lsblk', '-d', '-n', '-o', 'name,type,tran,serial'],stdout=subprocess.PIPE).communicate()[0]
    ret = ret.split("\n")
    for i in range(0,len(ret)-1):
		if ret[i].split()[1] == "disk" and ret[i].split()[2] != "usb":
			retVal.append([ret[i].split()[0],ret[i].split()[3]])
    return retVal


# System related
def sysInfo():
    subprocess.call(['clear'])
    ret = subprocess.Popen(['dmidecode','-t','1'],stdout=subprocess.PIPE).communicate()[0]
    print ret

def clearBMC():
    subprocess.call(['clear'])
    print "Listing contents..."
    print subprocess.Popen(['ipmitool','sel','list'],stdout=subprocess.PIPE).communicate()[0]
    while True:
        uI = raw_input("Are you sure you would like to clear contents(y/n)?")
        if uI == "y":
            subprocess.Popen(['ipmitool','sel','clear'],stdout=subprocess.PIPE).communicate()[0]
        elif uI == "n":
            break


# Sensor Related
def sensorInfo():
    while True:
        subprocess.call(['clear'])
        print "Choose sensor type:\n\n1. Temperature\n2. Fans\n3. All\n4. Previous Menu\n\n"
        uI = raw_input("Enter Choice: ")
        if uI == "1":
            __ipmitool("temperature")
        elif uI == "2":
            __ipmitool("fan")
        elif uI == "3":
            __ipmitool("")
        elif uI == "4":
            break

def __ipmitool(s):
    subprocess.call(['clear'])
    if s == "":
        print subprocess.Popen(['ipmitool','sdr'],stdout=subprocess.PIPE).communicate()[0]
    else:
        print subprocess.Popen(['ipmitool','sdr','type',s],stdout=subprocess.PIPE).communicate()[0]
    uI = raw_input("\n\nPress enter to continue...")


# Network Related
def netInfo():
    subprocess.call(['clear'])
    ret = subprocess.Popen(['ip','addr'],stdout=subprocess.PIPE).communicate()[0].split("\n")
    for i in range(0,len(ret)):
        nI = ['','','NA']
        if ret[i].find('link/ether') > -1:
            nI[0] = ret[i-1].split()[1].split(':')[0]
            nI[1] = ret[i].split()[1]
            if (i+1) < len(ret) and ret[i+1].find('inet') > -1 and ret[i+1].find('inet6') == -1:
                nI[2] = ret[i+1].split()[1].split('/')[0]
            print nI[0]+"\n----------------------------------\nMAC:\t"+nI[1]+"\nIPv4:\t"+nI[2]+"\n"
    
    uI = raw_input("\nPress enter to continue...")
