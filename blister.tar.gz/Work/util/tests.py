import hardware
import install
import subprocess
import os
import sys


class Tests:
    __CONST_PATH_MCE = '/var/log/mcelog'
    __testRunning = False
    __DIMM_LOC = ['A0', 'A1', 'B0', 'B1', 'C0', 'C1', 'D0',
                  'D1', 'E0', 'E1', 'F0', 'F1', 'G0', 'G1', 'H0', 'H1']
    __CONST_PATH = '/opt/mem-chk-tools/IDK/'
    __idk_running = False

    def __init__(self):
        self.__mceLen = 0
        self.__dimm_errors = []


    def memTest(self):  # todo:Automatic resizing of memtester memory allocation instead of by core.  Will take a little longer, but more accurate
        if self.__testRunning:
            print "Only one test allowed to run at a time..."
            return
        
        numCores = hardware.cores()
        mem = hardware.freeMem()
        memPerCore = (mem - (numCores * 30))/numCores
        i = 0
        self.__testRunning = True
        while(i < numCores):
            subprocess.Popen(['memtester', str(memPerCore)],stdout=open(os.devnull,'w')).pid
            i += 1
        

    def getDimmErrors(self):
        return self.__dimm_errors


    def __iniMemChk(self):  # Sets up IDK interface for finding location of DIMMS
        if self.__idk_running == False:  # todo:Use ps ax to see if process is actually running, instead of lazy check
            if not os.path.isdir(self.__CONST_PATH):
                install.memTools()  # todo:Need to check if there was error installing                            
                subprocess.call(['ln','-s',self.__CONST_PATH + 'IDK_Client/',os.path.dirname(__file__)+'/hyve'])
                import hyve.broadwell as broadwell
            
            tStr = self.__CONST_PATH + 'idk_core/'            
            os.chdir(tStr)
            # todo:Change to hide stdout
            subprocess.Popen(['./idk_core', '/listen', '/no_pat', '&'],stdout=open(os.devnull,'w')).pid
            self.__idk_running = True


    def getDimm(self, addr):  # Get DIMM location by address
        self.__iniMemChk()
        if not 'broadwell' in sys.modules:  # Using strictly broadwell library, will have to see if it works.  Thinking backwards compatible
            import hyve.broadwell as broadwell
            bw = broadwell.connect('localhost')
            ret = bw.AT_forward_translate('0x'+addr)
            return self.__DIMM_LOC[int(ret['socket']+ret['imc']+ret['channel']+ret['dimm'], 2)]
        else:
            bw = broadwell.connect('localhost')
            ret = bw.AT_forward_translate('0x'+addr)
            return self.__DIMM_LOC[int(ret['socket']+ret['imc']+ret['channel']+ret['dimm'], 2)]

    def checkMCE(self):       
        if os.path.getsize(self.__CONST_PATH_MCE) > self.__mceLen:  # todo:Find way to read partial file, maybe by byte instead of parsing whole file again for new errors            
            self.__mceLen = os.path.getsize(self.__CONST_PATH_MCE)
            with open(self.__CONST_PATH_MCE, 'r') as f:            
                for l in f:   #f is file, l reads lines from file(weird way to do it, would think l in f.readlines())
                    if l.find('MISC') > -1:                        
                        if l.find('ADDR') > -1:                            
                            tL = l.split()
                            if not __debug__:
                                dimm = self.getDimm(tL[len(tL) - 1])                                
                            else:
                                dimm = tL[len(tL)-1]
                                
                            if dimm not in self.__dimm_errors:
                                self.__dimm_errors.append(dimm)		
		        return self.__dimm_errors
        return None


    def stopMemTest(self):
        subprocess.call(['pkill','-9','memtester'])
        self.__testRunning = False


    def __del__(self):
        subprocess.call(['pkill','-9','memtester'])
        self.__testRunning = False
