import util.menu as menu
import util.install as install

def main():    
    menu.screen()

	
if __name__ == "__main__":
    main()
